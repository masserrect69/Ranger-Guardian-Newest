import fs from "node:fs/promises";
import path from "node:path";

const outputDir = path.resolve("knowledge/oem_public_downloads");

const sources = [
  {
    name: "ford_px_ranger_mkii_2019_bemm.pdf",
    url: "https://www.ford.com.au/content/dam/Ford/website-assets/ap/au/owner/vehicle-support/body-equipment-manuals/P375%20MY19%20TKD%20ASEAN%20BEMM-1.pdf"
  },
  {
    name: "ford_px_ranger_mkii_2015_bemm.pdf",
    url: "https://www.ford.com.au/content/dam/Ford/website-assets/ap/au/owner/vehicle-support/body-equipment-manuals/Body-Equipment-Manuals_au.pdf"
  }
];

const maxBytes = 30 * 1024 * 1024;

function assertAllowed(urlString) {
  const url = new URL(urlString);
  if (url.protocol !== "https:" || url.hostname !== "www.ford.com.au") {
    throw new Error(`Refusing non-Ford source: ${url.hostname}`);
  }
}

await fs.mkdir(outputDir, { recursive: true });

for (const source of sources) {
  assertAllowed(source.url);
  const target = path.join(outputDir, source.name);
  console.log(`Fetching ${source.name} ...`);
  const response = await fetch(source.url, {
    redirect: "follow",
    headers: { "User-Agent": "FordGuardian-RangerBrain/19 private-knowledge-fetcher" }
  });
  if (!response.ok) throw new Error(`${source.name}: HTTP ${response.status}`);
  const type = response.headers.get("content-type") || "";
  if (!type.includes("pdf")) throw new Error(`${source.name}: expected PDF, received ${type || "unknown"}`);
  const arrayBuffer = await response.arrayBuffer();
  if (arrayBuffer.byteLength > maxBytes) throw new Error(`${source.name}: exceeds ${maxBytes} byte safety limit`);
  await fs.writeFile(target, Buffer.from(arrayBuffer));
  console.log(`Saved ${target} (${arrayBuffer.byteLength} bytes)`);
}

console.log("\nPublic Ford source fetch complete. Run `npm run knowledge:setup` to create a new private vector store including these files.");
