# Licensed workshop manual intentionally omitted

Build the private OpenAI vector store from the full backend bundle first. The deployed server only needs the resulting FORD_RANGER_VECTOR_STORE_ID.
